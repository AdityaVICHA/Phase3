﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FlightSchedularMVC.Models
{
    [MetadataType(typeof(FlightMetaData))]
    public partial class Flight
    {
    }
}