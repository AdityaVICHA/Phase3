﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FlightSchedularMVC.Models;
using System.Net;
using System.Data.Entity;

namespace FlightSchedularMVC.Controllers
{
    public class FlightController : Controller
    {
        private FlightEntities2 db = new FlightEntities2();
        // GET: Flight
        public ActionResult Index()
        {
            var flights = db.Flight_bk.Include(e => e.AirportTerminal_bk).Include(e => e.FlightDeparture_bk).Include(e => e.FlightStatus_bk);
            return View(flights.ToList());
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Flight_bk flight = db.Flight_bk.Find(id);

            if (flight == null)
            {
                HttpNotFound();
            }

            return View(flight);
        }
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_bk flight = db.Flight_bk.Find(id);
            if (flight == null)
            {
                return HttpNotFound();
            }
            ViewBag.Status = new SelectList(db.FlightStatus_bk, "ID", "Description", flight.StatusId);
            ViewBag.TerminalName = new SelectList(db.AirportTerminal_bk, "ID", "TerminalName", flight.TerminalId);
            return View(flight);
        }

        [HttpPost]
        public ActionResult Edit([Bind(Include = "Id,Name,Destination,DepartureId,TerminalId,GateNo,StatusId")]Flight_bk flight,[Bind(Include = "Scheduled,Estimated,Actual")]FlightDeparture_bk flight_dept, [Bind(Include = "TerminalName")]AirportTerminal_bk flight_term, [Bind(Include = "Description")]FlightStatus_bk flight_status)
        {
            if (ModelState.IsValid)
            {
                db.Entry(flight).State = EntityState.Modified;
                flight.DepartureId = flight_dept.ID;
                flight.TerminalId = flight_term.ID;
                flight.StatusId = flight_status.ID;
                flight.FlightDeparture_bk = flight_dept;
                flight.FlightStatus_bk = flight_status;
                flight.AirportTerminal_bk = flight_term;
                //if (studentViewModel.Student.StudentID > 0)
                //    db.Students.Attach(studentViewModel.Student);
                //else
                //    db.Students.Add(studentViewModel.Student);
                db.Entry(flight).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(flight);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Flight_bk flight = db.Flight_bk.Find(id);
            if (id == null)
            {
                HttpNotFound();
            }

            return View(flight);
        }

    }
}