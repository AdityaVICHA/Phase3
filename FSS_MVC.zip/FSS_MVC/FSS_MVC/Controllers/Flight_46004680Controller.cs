﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FSS_MVC.Models;

namespace FSS_MVC.Controllers
{
    public class Flight_46004680Controller : Controller
    {
        private FlightEntities db = new FlightEntities();

        // GET: Flight_bk
        public ActionResult Index()
        {
            var flight = db.Flight_46004680.Include(f => f.AirportTerminal_46004680).Include(f => f.FlightDeparture_46004680).Include(f => f.FlightStatus_46004680);
            return View(flight.ToList());
        }


        // GET: Flight_bk/Details/5
        public ActionResult Search(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_46004680 flight = db.Flight_46004680.Find(id);
            if (flight == null)
            {
                return HttpNotFound();
            }
            return View(flight);
        }

        // GET: Flight_bk/Create
        public ActionResult Add()
        {
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_46004680, "ID", "TerminalName");
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_46004680, "ID", "ID");
            ViewBag.StatusId = new SelectList(db.FlightStatus_46004680, "ID", "Description");
            return View();
        }


        
        // POST: Flight_bk/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Add([Bind(Include = "ID,Name,Destination,DepartureId,TerminalId,GateNo,StatusId")] Flight_46004680 flight)
        {
            if (ModelState.IsValid)
            {
                db.Flight_46004680.Add(flight);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.TerminalId = new SelectList(db.AirportTerminal_46004680, "ID", "TerminalName", flight.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_46004680, "ID", "ID", flight.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_46004680, "ID", "Description", flight.StatusId);
            return View(flight);
        }

        // GET: Flight_bk/Edit/5
        public ActionResult Update(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_46004680 flight = db.Flight_46004680.Find(id);
            if (flight == null)
            {
                return HttpNotFound();
            }
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_46004680, "ID", "TerminalName", flight.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_46004680, "ID", "ID", flight.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_46004680, "ID", "Description", flight.StatusId);
            return View(flight);
        }

        // POST: Flight_bk/Edit/5
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Update([Bind(Include = "ID,Name,Destination,DepartureId,TerminalId,GateNo,StatusId")] Flight_46004680 flight)
        {
            if (ModelState.IsValid)
            {
                db.Entry(flight).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.TerminalId = new SelectList(db.AirportTerminal_46004680, "ID", "TerminalName", flight.TerminalId);
            ViewBag.DepartureId = new SelectList(db.FlightDeparture_46004680, "ID", "ID", flight.DepartureId);
            ViewBag.StatusId = new SelectList(db.FlightStatus_46004680, "ID", "Description", flight.StatusId);
            return View(flight);
        }

        // GET: Flight_bk/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight_46004680 flight = db.Flight_46004680.Find(id);
            if (flight == null)
            {
                return HttpNotFound();
            }
            return View(flight);
        }

        // POST: Flight_bk/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Flight_46004680 flight = db.Flight_46004680.Find(id);
            db.Flight_46004680.Remove(flight);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
